package MR.ArMLMessageParser;

import java.util.regex.Pattern;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	Pattern pattern = Pattern.compile("<arml>");
    	
        System.out.println(pattern );
    }
    
    
    
    
   
}
